
# Contact Form Backend

This Express.js server accepts POST requests from your frontend and emails the submitted form data using Gmail.

## 🛠 How to Use

1. Rename `.env` and replace `GMAIL_PASS` with your **16-digit Gmail App Password**.
2. Run:
    ```bash
    npm install
    npm start
    ```
3. Deploy to Render:
   - Create new Web Service
   - Set build command: `npm install`
   - Set start command: `node server.js`
   - Add ENV variables:
     - `GMAIL_USER = rayallapavansai@gmail.com`
     - `GMAIL_PASS = your 16-digit app password`
4. Your endpoint: `https://your-backend.onrender.com/api/contact`

